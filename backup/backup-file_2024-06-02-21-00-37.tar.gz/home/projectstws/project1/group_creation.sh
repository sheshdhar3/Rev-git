#!/bin/bash

echo "enter group name"
read groupname

sudo groupadd $groupname


echo "Group created"
