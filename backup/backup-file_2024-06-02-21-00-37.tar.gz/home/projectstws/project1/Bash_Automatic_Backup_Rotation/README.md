# BashAutomaticbackup

This script creates a backup of the specified directory as a argument(Enter the location to backup) and then checks if there are more than the specified maximum number of backups (max_backups).
If there are more than the maximum number of backups, it deletes the oldest backup.
